package com.cg.Factories;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {
	WebDriver driver;
@FindBy(how=How.NAME,using="userName")
@CacheLookup
	WebElement userName;
@FindBy(how=How.ID,using="userErrMsg")
@CacheLookup
	WebElement unameErr;
@FindBy(how=How.NAME,using="userPwd")
@CacheLookup
	WebElement password;
@FindBy(how=How.ID,using="pwdErrMsg")
@CacheLookup
	WebElement passErr;
@FindBy(how=How.CLASS_NAME,using="btn")
@CacheLookup
WebElement lgbtn;
public LoginPageFactory(WebDriver driver) {
	// TODO Auto-generated constructor stub
	this.driver = driver;
	PageFactory.initElements(driver, this);
}
public WebElement getLgbtn() {
	return lgbtn;
}
public void setLgbtn() {
	this.lgbtn.click();
}
public WebDriver getDriver() {
	return driver;
}
public void setDriver(WebDriver driver) {
	this.driver = driver;
}
public WebElement getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName.sendKeys(userName);
}
public WebElement getUnameErr() {
	return unameErr;
}
public void setUnameErr(WebElement unameErr) {
	this.unameErr = unameErr;
}
public WebElement getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password.sendKeys(password);
}
public WebElement getPassErr() {
	return passErr;
}
public void setPassErr(WebElement passErr) {
	this.passErr = passErr;
}

}
