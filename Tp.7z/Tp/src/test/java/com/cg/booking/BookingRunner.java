package com.cg.booking;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty"},features="D:\\Users\\sopendya\\Desktop\\Tp\\Features\\booking.feature")
public class BookingRunner {

	
}
