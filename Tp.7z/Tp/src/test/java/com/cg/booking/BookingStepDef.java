package com.cg.booking;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookingStepDef {

@Given("^user is on 'hotelBooking' page$")
public void user_is_on_hotelBooking_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters invalid first name$")
public void user_enters_invalid_first_name() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^displays 'Please fill the first Name'$")
public void displays_Please_fill_the_first_Name() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters invalid last name$")
public void user_enters_invalid_last_name() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^displays 'Please fill the Last Name'$")
public void displays_Please_fill_the_Last_Name() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters invalid email$")
public void user_enters_invalid_email() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^display 'Please fill the Email'$")
public void display_Please_fill_the_Email() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters invalid mobile number$")
public void user_enters_invalid_mobile_number() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^display 'Please fill Mobile No\\.'$")
public void display_Please_fill_Mobile_No() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters wrong mobile number$")
public void user_enters_wrong_mobile_number() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^display 'Please enter valid Mobile Number'$")
public void display_Please_enter_valid_Mobile_Number() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters invalid Number of People staying$")
public void user_enters_invalid_Number_of_People_staying() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^display 'Number of people staying'$")
public void display_Number_of_people_staying() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user does not enter address$")
public void user_does_not_enter_address() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^display 'Please Enter Address'$")
public void display_Please_Enter_Address() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}
}
