package com.cg.login;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions( plugin = {"pretty"},features="D:\\Users\\sopendya\\Desktop\\Tp\\Features\\login.feature")
public class LoginRunner {

}
