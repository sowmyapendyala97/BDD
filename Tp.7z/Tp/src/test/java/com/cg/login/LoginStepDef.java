package com.cg.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.cg.Factories.LoginPageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDef {
	private WebDriver driver;
	private LoginPageFactory lpf;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:/Users/sopendya/Downloads/chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	@Given("^User is on 'login' Page$")
	public void user_is_on_login_Page() {
		driver.get("D:\\Users\\sopendya\\Desktop\\BDDCaseStudyFinal\\login.html");
		lpf= new LoginPageFactory(driver);
	}

	
	
	@When("^user enters invalid UserName$")
	public void user_enters_invalid_UserName() throws Throwable  {
	   lpf.setUserName("");
	   lpf.setLgbtn();
	
	}

	@Then("^display 'Please Enter UserName'$")
	public void display_Please_Enter_UserName()  {
		String expectedMessage="* Please enter userName.";
		String actualMessage=lpf.getUnameErr().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();	

	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password()  {
		  lpf.setUserName("Sowmya");
		  lpf.setPassword("");
		   lpf.setLgbtn();
	}

	@Then("^display 'Please Enter Password'$")
	public void display_Please_Enter_Password() {
		String expectedMessage="* Please enter password.";
		String actualMessage=lpf.getPassErr().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.close();
	}

	@When("^user enters invalid details$")
	public void user_enters_invalid_details() {
		  lpf.setUserName("Sunil");
		  lpf.setPassword("Sunil");
		   lpf.setLgbtn();
	}
	@Then("^display 'Invalid Login Please try again'$")
	public void display_Invalid_Login_Please_try_again() {
		String expectedMessage="Invalid login! Please try again!";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details(){
		lpf.setUserName("Sowmya");
		  lpf.setPassword("Sunil");
		   lpf.setLgbtn();
	}

	@Then("^display 'HotelBooking' Page$")
	public void display_HotelBooking_Page() {
		driver.switchTo().alert().accept();
		driver.get("D:\\Users\\sopendya\\Desktop\\BDDCaseStudyFinal\\hotelbooking.html");
	}
}
